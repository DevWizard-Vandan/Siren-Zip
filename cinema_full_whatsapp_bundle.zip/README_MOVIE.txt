=======================================================
⚡ SIREN-ZIP CINEMA CONTAINER BUNDLE
=======================================================
Container File    : cinema_full.neura
Container Size    : 3.40 MB
Platform Target   : WHATSAPP (Limit: 16.0 MB)
Status            : APPROVED (Ready for instant sending)

Movie Information:
- Native Res     : 1920x1080 Full HD
- Total Duration : 12.01 seconds
- Neural GOPs    : 4 Chunks
- Audio Track    : 2 channels @ 48000 Hz
- Color Space    : Rec.709 SDR

How to Play:
1. Ensure Python 3.10+ and requirements (pip install -r requirements.txt) are installed.
2. Double-click 'play_movie.bat' or run:
   python scripts/launch_vlc.py --file "cinema_full.neura"
=======================================================
