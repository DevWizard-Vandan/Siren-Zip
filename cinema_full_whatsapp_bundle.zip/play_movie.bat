@echo off
title Siren-VLC Player
echo Starting Siren-VLC Player for cinema_full.neura...
python -m src.ui.main_window --file "cinema_full.neura"
if errorlevel 1 (
    python scripts/launch_vlc.py --file "cinema_full.neura"
)
pause
